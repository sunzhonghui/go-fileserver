# go-fileserver
golang 搭建简易文件服务器